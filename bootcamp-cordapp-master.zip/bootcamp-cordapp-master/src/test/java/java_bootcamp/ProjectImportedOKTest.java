package java_bootcamp;

import org.junit.Test;

public class ProjectImportedOKTest {
    @Test
    public void projectImportedOKTest() {

    }
}
